package birthdayCelebration_interfacesAbstraction;

public interface Identifiable {
    String getId();
}
