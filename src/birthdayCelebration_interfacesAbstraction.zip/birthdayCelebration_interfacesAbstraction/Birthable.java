package birthdayCelebration_interfacesAbstraction;

public interface Birthable {
    String getBirthDate();
}
