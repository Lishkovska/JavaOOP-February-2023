package defineInterfacePerson_interfacesAbstraction;

public interface Birthable {
    String getBirthDate();
}
