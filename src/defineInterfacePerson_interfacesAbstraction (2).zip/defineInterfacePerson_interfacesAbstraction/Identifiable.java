package defineInterfacePerson_interfacesAbstraction;

public interface Identifiable {
    String getId();
}
