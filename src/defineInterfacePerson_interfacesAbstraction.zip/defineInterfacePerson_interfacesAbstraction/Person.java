package defineInterfacePerson_interfacesAbstraction;

public interface Person {

    String getName();
    int getAge();

}
