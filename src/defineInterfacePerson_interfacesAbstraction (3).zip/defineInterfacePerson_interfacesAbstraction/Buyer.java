package defineInterfacePerson_interfacesAbstraction;

public interface Buyer {
    void buyFood();
    int getFood();
}
