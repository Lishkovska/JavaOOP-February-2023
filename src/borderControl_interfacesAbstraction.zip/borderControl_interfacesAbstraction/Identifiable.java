package borderControl_interfacesAbstraction;

public interface Identifiable {
    String getId();
}
