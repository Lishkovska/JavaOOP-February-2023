package sayHello_interfacesAbstraction;

public interface Person {
    String getName();
    String sayHello();
}
