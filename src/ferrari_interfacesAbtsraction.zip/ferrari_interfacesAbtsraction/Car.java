package ferrari_interfacesAbtsraction;

public interface Car {
    String brakes();
    String gas();
}
