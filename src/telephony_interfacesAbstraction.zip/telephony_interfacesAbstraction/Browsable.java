package telephony_interfacesAbstraction;

public interface Browsable {
    String browse();
}
