package telephony_interfacesAbstraction;

public interface Callable {
    String call();
}
