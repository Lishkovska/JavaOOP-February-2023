package hiericalInheritance_inheritance;

public class Cat extends Animal {
    public void meow(){
        System.out.println("meowing...");
    }
}
