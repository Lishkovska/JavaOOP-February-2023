package singleInheritance_inheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
