package shoppingSpree_encapsulation;

public class Main {
    public static void main(String[] args) {
        
    }
}
