package carShop_interfacesAbstraction;

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();

}
