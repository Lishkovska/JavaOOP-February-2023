package carShop_interfacesAbstraction;

public interface Sellable {
    Double getPrice();

}
