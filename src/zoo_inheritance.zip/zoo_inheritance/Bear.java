package zoo_inheritance;

public class Bear extends Mammal {
    public Bear(String name) {
        super(name);
    }
}
