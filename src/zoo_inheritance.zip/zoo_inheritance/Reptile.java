package zoo_inheritance;

public class Reptile extends Animal {
    public Reptile(String name) {
        super(name);
    }


}
